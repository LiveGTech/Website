# Important information for this press kit
Thank you for expressing an interest in covering LiveG's products and services in your publications.

This press kit contains various files and assets that you may use in your publications. A copy of the press release is available for your convenience as the file named **Press release.md**. The press release also contains useful links to documents and media available online, in addition to contact information for any press enquiries.

## Licensing and attribution
All assets provided in this press kit are released under the LiveG Open-Source Licence. You are free to use these assets for the purposes of producing your publications. If you are looking to use these assets in other publications that do not discuss LiveG, then you must provide attribution (the simplest permissible form is having a caption which contains 'LiveG').

There is no need for you to include a copy of the LiveG Open-Source Licence in your publication; and likewise, you do not need to provide a notice to inform readers that assets are licensed as such.

A copy of the LiveG Open-Source Licence is available in the file named **LICENCE.md**.

## Trademarks and other legal information
For other important legal information — including the use of LiveG's trademarks in your publication — please visit [liveg.tech/legal](https://liveg.tech/legal).