# LiveG Open-Source Licence
Copyright © LiveG. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this material and associated documentation files (the 'material'), to
apply any actions to the copied material in any form, including without
limitation the rights to use, to modify, to publish, to distribute, to
relicense and/or to sell, subject to the following conditions:

The above copyright notice and this licence shall be included in all copies
or substantial portions of this material.

THIS MATERIAL IS PROVIDED 'AS-IS', WITHOUT WARRANTY OF ANY KIND. IN NO EVENT
SHOULD THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIMS, DAMAGES OR
OTHER LIABILITIES.
